<?php
defined('_JEXEC') or die;
class ModReallyGlassHelper {
  public static function getCards() {
    return [
      (object)['title' => 'Card 1', 'text' => 'This works'],
      (object)['title' => 'Card 2', 'text' => 'No bullshit']
    ];
  }
}