<?php
defined('_JEXEC') or die;
?>
<div id="read-progress-container" style="position:fixed;top:0;left:0;width:100%;height:5px;background:#f0f0f0;z-index:9999">
  <div id="read-progress-bar" style="height:100%;width:0%;background:#4CAF50"></div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const progressBar = document.getElementById('read-progress-bar');
  const article = document.querySelector('.item-page') || document.querySelector('article') || document.querySelector('body');
  
  window.addEventListener('scroll', function() {
    const articleHeight = article.offsetHeight;
    const windowHeight = window.innerHeight;
    const scrollPosition = window.scrollY || window.pageYOffset;
    const progress = (scrollPosition / (articleHeight - windowHeight)) * 100;
    progressBar.style.width = Math.min(100, Math.max(0, progress)) + '%';
  });
});
</script>